from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken

from .models import Appointment
from .serializers import (RegisterSerializer, LoginSerializer, AppointmentSerializer,
                          CreateAppointmentSerializer, UpdateAppointmentSerializer)


# API 1: Register
@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    serializer = RegisterSerializer(data=request.data)
    if serializer.is_valid():
        patient = serializer.save()

        # Generate tokens
        refresh = RefreshToken.for_user(patient.user)

        return Response({
            'message': 'Patient registered successfully',
            'patient': {
                'id': patient.user.id,
                'username': patient.user.username,
                'name': patient.user.get_full_name(),
                'email': patient.user.email,
                'phone': patient.user.phone_number
            },
            'tokens': {
                'refresh': str(refresh),
                'access': str(refresh.access_token),
            }
        }, status=status.HTTP_201_CREATED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# API 2: Patient Login
@api_view(['POST'])
@permission_classes([AllowAny])
def patient_login(request):
    serializer = LoginSerializer(data=request.data)
    if serializer.is_valid():
        username = serializer.validated_data['username']
        password = serializer.validated_data['password']

        user = authenticate(username=username, password=password)

        if user and hasattr(user, 'patient'):
            refresh = RefreshToken.for_user(user)

            return Response({
                'message': 'Patient login successful',
                'patient': {
                    'id': user.id,
                    'username': user.username,
                    'name': user.get_full_name(),
                    'email': user.email,
                    'phone': user.phone_number
                },
                'tokens': {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                }
            })

        return Response({'error': 'Invalid credentials or not a patient'},
                        status=status.HTTP_401_UNAUTHORIZED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# API 3: Doctor Login
@api_view(['POST'])
@permission_classes([AllowAny])
def doctor_login(request):
    serializer = LoginSerializer(data=request.data)
    if serializer.is_valid():
        username = serializer.validated_data['username']
        password = serializer.validated_data['password']

        user = authenticate(username=username, password=password)

        if user and hasattr(user, 'doctor'):
            refresh = RefreshToken.for_user(user)

            return Response({
                'message': 'Doctor login successful',
                'doctor': {
                    'id': user.id,
                    'username': user.username,
                    'name': user.get_full_name(),
                    'email': user.email,
                    'phone': user.phone_number,
                    'specialization': user.doctor.specialization,
                    'license_number': user.doctor.license_number
                },
                'tokens': {
                    'refresh': str(refresh),
                    'access': str(refresh.access_token),
                }
            })

        return Response({'error': 'Invalid credentials or not a doctor'},
                        status=status.HTTP_401_UNAUTHORIZED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# API 4: Booking (Create Appointment)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_appointment(request):
    # Check if user is a patient
    if not hasattr(request.user, 'patient'):
        return Response({'error': 'Only patients can create appointments'},
                        status=status.HTTP_403_FORBIDDEN)

    serializer = CreateAppointmentSerializer(data=request.data)
    if serializer.is_valid():
        # Add the patient to the appointment
        appointment = serializer.save(patient=request.user.patient)

        return Response({
            'message': 'Appointment created successfully',
            'appointment': AppointmentSerializer(appointment).data
        }, status=status.HTTP_201_CREATED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# API 5: Doctor - Update Appointment
@api_view(['PATCH'])
@permission_classes([IsAuthenticated])
def update_appointment(request, appointment_id):
    # Check if user is a doctor
    if not hasattr(request.user, 'doctor'):
        return Response({'error': 'Only doctors can update appointments'},
                        status=status.HTTP_403_FORBIDDEN)

    try:
        appointment = Appointment.objects.get(id=appointment_id, doctor=request.user.doctor)
    except Appointment.DoesNotExist:
        return Response({'error': 'Appointment not found'},
                        status=status.HTTP_404_NOT_FOUND)

    serializer = UpdateAppointmentSerializer(appointment, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()

        return Response({
            'message': 'Appointment updated successfully',
            'appointment': AppointmentSerializer(appointment).data
        })

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Additional helper endpoint: Get appointments for authenticated user
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_my_appointments(request):
    if hasattr(request.user, 'patient'):
        appointments = Appointment.objects.filter(patient=request.user.patient)
    elif hasattr(request.user, 'doctor'):
        appointments = Appointment.objects.filter(doctor=request.user.doctor)
    else:
        return Response({'error': 'User type not recognized'},
                        status=status.HTTP_400_BAD_REQUEST)

    serializer = AppointmentSerializer(appointments, many=True)
    return Response({'appointments': serializer.data})
