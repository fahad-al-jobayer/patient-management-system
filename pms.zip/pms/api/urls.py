from django.urls import path
from . import views

urlpatterns = [
    # API 1: Register
    path('register/', views.register, name='register'),

    # API 2: Patient Login
    path('patient/login/', views.patient_login, name='patient-login'),

    # API 3: Doctor Login
    path('doctor/login/', views.doctor_login, name='doctor-login'),

    # API 4: Booking (Create Appointment)
    path('appointments/create/', views.create_appointment, name='create-appointment'),

    # API 5: Doctor - Update Appointment
    path('appointments/<int:appointment_id>/update/', views.update_appointment, name='update-appointment'),

    # Additional endpoint: Get user's appointments
    path('appointments/my/', views.get_my_appointments, name='my-appointments'),
]