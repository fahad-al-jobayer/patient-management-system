from django.contrib.auth.hashers import make_password
from rest_framework import serializers

from .models import User, Patient, Appointment


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'first_name', 'last_name',
                  'user_type', 'phone_number', 'date_of_birth', 'address')
        extra_kwargs = {'password': {'write_only': True}}


class RegisterSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)
    first_name = serializers.CharField(max_length=30)
    last_name = serializers.CharField(max_length=30)
    phone_number = serializers.CharField(max_length=17)
    address = serializers.CharField()
    gender = serializers.ChoiceField(choices=[('M', 'Male'), ('F', 'Female'), ('O', 'Other')])
    emergency_contact = serializers.CharField(max_length=100)

    def create(self, validated_data):
        # Extract user data
        user_data = {
            'username': validated_data['username'],
            'email': validated_data['email'],
            'password': make_password(validated_data['password']),
            'first_name': validated_data['first_name'],
            'last_name': validated_data['last_name'],
            'phone_number': validated_data['phone_number'],
            'address': validated_data['address'],
            'user_type': 'patient'
        }

        # Create user
        user = User.objects.create(**user_data)

        # Create patient profile
        patient = Patient.objects.create(
            user=user,
            gender=validated_data['gender'],
            emergency_contact=validated_data['emergency_contact']
        )

        return patient


class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()


class AppointmentSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.user.get_full_name', read_only=True)
    doctor_name = serializers.CharField(source='doctor.user.get_full_name', read_only=True)

    class Meta:
        model = Appointment
        fields = '__all__'


class CreateAppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = ('doctor', 'date', 'symptoms')


class UpdateAppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = ('status', 'prescription', 'description')