# Clinic Backend (Django + DRF + JWT + MySQL)

## Quick Start

1) Create MySQL DB & user:
```sql
CREATE DATABASE clinic_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'clinic_user'@'%' IDENTIFIED BY 'StrongP@ss123';
GRANT ALL PRIVILEGES ON clinic_db.* TO 'clinic_user'@'%';
FLUSH PRIVILEGES;
```

2) Install deps and run migrations:
```bash
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser  # create an admin (also use for doctor users)
python manage.py runserver
```

3) Create a doctor user:
- In Django admin, edit user -> tick `is_doctor`, set password.
- (Patients are created through the register API.)

## APIs

- POST `/api/patients/register/`  
  Body: `{"username":"harsh","email":"h@x.com","password":"pass","phone":"...","address":"..."}`

- POST `/api/patients/login/` → returns JWT
- POST `/api/doctors/login/` → returns JWT
- POST `/api/appointments/` (Auth required)  
  Body: `{"patient":1,"doctor":2,"date":"2025-10-01T10:00:00Z","symptoms":"..."}`
- PATCH `/api/appointments/{id}/` (Doctor + Auth)  
  Body: `{"status":"confirmed","prescription":"Paracetamol","description":"Take after meals"}`

Use header: `Authorization: Bearer <access_token>`
