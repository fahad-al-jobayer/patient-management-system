from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from rest_framework_simplejwt.tokens import RefreshToken
from django.shortcuts import get_object_or_404
from .models import Appointment
from .serializers import RegisterPatientSerializer, LoginSerializer, AppointmentSerializer

# 1. Patient Registration
class PatientRegisterView(APIView):
    permission_classes = [permissions.AllowAny]
    def post(self, request):
        serializer = RegisterPatientSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response({"message": "Patient registered successfully", "user_id": user.id}, status=201)
        return Response(serializer.errors, status=400)

# Helper: issue JWT tokens
def issue_tokens_for(user):
    refresh = RefreshToken.for_user(user)
    return {"refresh": str(refresh), "access": str(refresh.access_token)}

# 2. Patient Login (returns JWT)
class PatientLoginView(APIView):
    permission_classes = [permissions.AllowAny]
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            if not user.is_patient:
                return Response({"error": "Not a patient account"}, status=403)
            tokens = issue_tokens_for(user)
            return Response({"message": "Login successful", "user_id": user.id, **tokens})
        return Response(serializer.errors, status=400)

# 3. Doctor Login (returns JWT)
class DoctorLoginView(APIView):
    permission_classes = [permissions.AllowAny]
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            if not user.is_doctor:
                return Response({"error": "Not a doctor account"}, status=403)
            tokens = issue_tokens_for(user)
            return Response({"message": "Login successful", "user_id": user.id, **tokens})
        return Response(serializer.errors, status=400)

# 4. Booking Appointment (Patient creates appointment)
class AppointmentCreateView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    def post(self, request):
        serializer = AppointmentSerializer(data=request.data)
        if serializer.is_valid():
            appt = serializer.save()
            return Response({"message": "Appointment booked successfully", "appointment_id": appt.id}, status=201)
        return Response(serializer.errors, status=400)

# 5. Doctor updates appointment: confirm, prescription, description
class DoctorAppointmentUpdateView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    def patch(self, request, pk:int):
        appt = get_object_or_404(Appointment, pk=pk)
        # (Optional) authorize: only doctors can update
        if not request.user.is_doctor:
            return Response({"error": "Only doctors can update appointments."}, status=403)
        serializer = AppointmentSerializer(appt, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({"message": "Appointment updated successfully"})
        return Response(serializer.errors, status=400)
