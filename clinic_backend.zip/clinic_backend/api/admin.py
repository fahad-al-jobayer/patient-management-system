from django.contrib import admin
from .models import User, PatientProfile, DoctorProfile, Appointment

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('id','username','email','is_patient','is_doctor','is_staff')

@admin.register(PatientProfile)
class PatientAdmin(admin.ModelAdmin):
    list_display = ('id','user','phone','address')

@admin.register(DoctorProfile)
class DoctorAdmin(admin.ModelAdmin):
    list_display = ('id','user','specialization','experience_years')

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('id','patient','doctor','date','status','created_at')
    list_filter = ('status','date')
