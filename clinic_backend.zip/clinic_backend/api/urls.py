from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    PatientRegisterView, PatientLoginView, DoctorLoginView,
    AppointmentCreateView, DoctorAppointmentUpdateView
)

urlpatterns = [
    path('patients/register/', PatientRegisterView.as_view()),
    path('patients/login/', PatientLoginView.as_view()),
    path('doctors/login/', DoctorLoginView.as_view()),
    path('appointments/', AppointmentCreateView.as_view()),
    path('appointments/<int:pk>/', DoctorAppointmentUpdateView.as_view()),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
