from rest_framework import serializers
from django.contrib.auth import authenticate
from .models import User, PatientProfile, DoctorProfile, Appointment

class RegisterPatientSerializer(serializers.ModelSerializer):
    phone = serializers.CharField(required=False, allow_blank=True)
    address = serializers.CharField(required=False, allow_blank=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'phone', 'address']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        phone = validated_data.pop('phone', '')
        address = validated_data.pop('address', '')
        user = User.objects.create_user(**validated_data, is_patient=True)
        PatientProfile.objects.create(user=user, phone=phone, address=address)
        return user

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        user = authenticate(username=data['username'], password=data['password'])
        if not user:
            raise serializers.ValidationError("Invalid credentials")
        return {'user': user}

class AppointmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Appointment
        fields = '__all__'

    def validate(self, attrs):
        # Ensure patient/doctor are correct roles
        patient = attrs.get('patient')
        doctor = attrs.get('doctor')
        if patient and not patient.is_patient:
            raise serializers.ValidationError({'patient': 'Selected user is not a patient.'})
        if doctor and not doctor.is_doctor:
            raise serializers.ValidationError({'doctor': 'Selected user is not a doctor.'})
        return attrs
